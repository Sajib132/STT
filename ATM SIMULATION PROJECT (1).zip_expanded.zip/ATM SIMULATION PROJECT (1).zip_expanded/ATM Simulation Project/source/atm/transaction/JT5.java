package atm.transaction;

import static org.junit.Assert.*;

import org.junit.Test;

import banking.Message;

public class JT5 {

	@Test
	public void test_variable_message5() {
		int Testtransfer=3;
		assertEquals(Testtransfer,Message.TRANSFER);
	}
}
