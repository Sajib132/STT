package atm.transaction;

import static org.junit.Assert.*;

import org.junit.Test;

import banking.Message;

public class JT4 {

	@Test
	public void test_variable_message4() {
		int Testinquiry=4;
		assertEquals(Testinquiry,Message.INQUIRY);
	}

}
