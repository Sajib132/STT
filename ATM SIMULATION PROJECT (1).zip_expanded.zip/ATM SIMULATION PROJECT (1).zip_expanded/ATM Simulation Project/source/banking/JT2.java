package banking;

import static org.junit.Assert.*;

import org.junit.Test;

public class JT2 {

	@Test
	public void test_variable_message2() {
		int Test_initial_deposite=1;
		assertEquals(Test_initial_deposite,Message.INITIATE_DEPOSIT);
		
	}

}
