package banking;

import static org.junit.Assert.*;

import org.junit.Test;

public class JT1 {

	@Test
	public void test_variable_message1() {
		int Test_Complete_deposite=2;
		assertEquals(Test_Complete_deposite,Message.COMPLETE_DEPOSIT);
	}

}
